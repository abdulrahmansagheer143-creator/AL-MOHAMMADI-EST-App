#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/android/app/src/main/assets/web"
cp -R "$ROOT/web/." "$ROOT/android/app/src/main/assets/web/"
