# AL-MOHAMMADI EST – Complete App Source (Preview)

This package contains one shared web app for Android/iPhone installation (PWA) plus an Android Studio project for producing an APK.

## Original invoice/contract

`web/invoice.html` is copied byte-for-byte from the earlier Contract Maker A4 Arabic contract screen. The A4 invoice/contract design, Arabic text, fields, amount-in-words logic, instalment calculation, saved-contract history, PDF/print and WhatsApp action are kept as the original screen. The app opens it under **Invoice / Contract**. The CRM can prefill the customer name and phone into the original form; it does not redesign the printed contract.

SHA-256: `bfa0f03690fa4538132a2fa3d816d3d7599533ed3119523ceb7ac3f36c434d45`

## Included modules

- Dashboard: monthly collected payments, due payments, total customers, saved original contracts, visits today and low stock.
- Customers: customer and pool details; launch original contract with customer name/phone filled in.
- Operations: visits with technician, service type, pH/chlorine readings, chemicals used and next visit; repair/construction jobs; chemical/equipment inventory with reorder levels.
- Finance: payment receipt tracking and operating expenses.
- Reports: six-month collection chart and management summaries.
- Settings: company profile, English/Arabic interface.
- Backup/restore: JSON export/import including original invoice history.
- PWA install/offline shell for supported browsers.

## Important limitations

This is a local-first prototype. Data is stored on the current device/browser only. It is not yet multi-user, cloud-synchronised or server-backed. Manual JSON backup is included. Do not put real production customer data into shared devices until authentication, cloud access controls, encrypted backups, retention rules and privacy disclosures have been implemented and tested.

Finance/payment records are internal management tracking only. They are **not** ZATCA-compliant tax invoices and do not connect to FATOORA. If the company is required to use ZATCA e-invoicing, use a compliant provider/integration after confirming the company's VAT registration and applicable ZATCA wave.

The current contract template includes company/customer/bank details and a sample customer prefilled in the original source. Review every field before sending a contract. The invoice screen was intentionally preserved as requested; changing its printed content requires the company to approve the changes separately.

## Android APK build

Open the `android` folder in Android Studio (JDK 17, Android SDK Platform 35, Gradle 8.9+). Before a local Android Studio build, run `bash prepare_web_assets.sh` from the package root so the shared web files are copied into Android assets. The included GitHub Actions workflow performs this automatically. Or use the GitHub Actions workflow at `.github/workflows/build-apk.yml` after uploading this source ZIP as `AL-MOHAMMADI-EST-Complete-App.zip` to the repository root. The artifact is a debug/test APK targeting Android API 34, not a signed Play Store release. Before store submission, raise target SDK to the then-current Play requirement and verify Android 15+ edge-to-edge insets.

## iPhone

Host the `web` folder on an HTTPS static host (GitHub Pages/Cloudflare Pages). Open the URL in Safari → Share → Add to Home Screen. This produces a home-screen web app; it is not an App Store IPA. Native iOS distribution requires an Apple signing/build workflow and Apple Developer account.

## Hosting as PWA

Deploy the contents of `web/` to a static HTTPS host. Keep `index.html`, `invoice.html`, `app.js`, `sw.js`, `manifest.webmanifest`, and `assets/` at the same root. The PWA has an offline app shell. The invoice itself uses localStorage for the original saved contracts.
