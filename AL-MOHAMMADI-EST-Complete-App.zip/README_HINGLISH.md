# AL-MOHAMMADI EST – Hinglish setup guide

## Aapki requirement kaise follow ki hai
- App ka naam aur icon: **AL-MOHAMMADI EST**.
- Original Arabic A4 contract/invoice ko `web/invoice.html` mein exact copy rakha gaya hai. Print hone wala design aur text change nahi kiya.
- Invoice ke bahar business modules add kiye: customers, maintenance visits, repair/construction jobs, inventory, payments, expenses, reports, company profile aur backup/restore.
- English aur Arabic interface toggle.
- Android APK project + iPhone ke liye installable PWA web app.

## Android APK
`AL-MOHAMMADI-EST-Complete-App.zip` GitHub repository ke root mein upload karna hoga. GitHub Actions mein **Build AL-MOHAMMADI EST APK** run hoga. Workflow automatically `web` files ko Android assets mein copy karega. Success hone ke baad Artifacts se APK download karein, ZIP extract karein aur APK install karein.

## iPhone
`web` folder ko HTTPS website par publish karein. iPhone par Safari mein website khol kar Share → Add to Home Screen karein.

## Important
Abhi records ek phone/browser mein local save hote hain. Cloud sync, employee login/roles, automatic remote backup aur ZATCA FATOORA integration abhi nahi hain. Original invoice mein prefilled customer, bank and contact details ko issue karne se pehle verify karein. Is prototype ka payment tracker tax invoice nahi hai.
