# Release checklist

## Invoice preservation
- Source invoice copied byte-for-byte from the earlier project.
- SHA-256: `bfa0f03690fa4538132a2fa3d816d3d7599533ed3119523ceb7ac3f36c434d45`
- Outer app can populate customer name and phone via same-origin iframe access; it does not change the printed template.

## Before live company rollout
- Verify every prefilled phone, address, CR and IBAN inside original invoice.
- Test PDF print A4 on actual Android device and Safari iOS.
- Add secure cloud database, user accounts and role permissions before employees share live records.
- Add encrypted backups, restore testing, audit log and retention policy.
- Review Saudi PDPL obligations and publish a privacy notice.
- Confirm ZATCA applicability; this internal tracker is not a ZATCA e-invoice system.
- Conduct chemical handling and technician safety review.
- Test Arabic RTL display, number/date formats and WhatsApp sharing.

## Current package test status
- HTML files included and localStorage modules wired.
- PWA manifest and service worker included.
- Android wrapper uses AndroidX WebViewAssetLoader rather than file:// access.
- Actual APK compile still needs GitHub Actions/Android SDK validation.
- iOS included as PWA install path; App Store IPA not included.
