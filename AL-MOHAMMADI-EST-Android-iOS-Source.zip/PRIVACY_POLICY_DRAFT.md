# Privacy Policy – Draft for AL-MOHAMMADI EST

**Status: Draft template – must be reviewed and published at a public HTTPS URL before App Store submission.** Replace the bracketed details and revise this policy after cloud services, analytics, messaging, location or other third-party tools are added.

Effective date: [Insert date]

Company / operator: [Insert legal company name]
Contact: [Insert support email and business address]

## 1. Data stored in this preview

The preview version stores records entered by the app user on the same device using local application storage. These records may include customer names, telephone numbers, addresses, pool information, contract details, service visits, payment records, inventory and company profile details.

## 2. Where data is stored

This preview does not connect to a company cloud database or provide cross-device synchronisation. Local records may be lost if the app is removed, application data is cleared or the device is lost. Users should not enter live customer information until the company has approved the storage and backup arrangements. A user may share an exported JSON backup using the device share sheet; the export is not encrypted and must be treated as confidential company data.

## 3. Sharing

When a user chooses to create or share a PDF, the device's operating-system share sheet is opened. The user selects the destination app or recipient. AL-MOHAMMADI EST does not automatically send messages in this preview.

## 4. Security

The company should complete a security review before production use. This preview does not provide organisation accounts, employee permissions, encrypted cloud backup or remote account management.

## 5. Retention and deletion

Records remain in local application storage until deleted in the app or the application data is removed. [Add the final production data retention and deletion process here.]

## 6. Children's privacy

This business application is intended for business users and is not designed for children.

## 7. Changes and contact

The company may update this policy when features or data handling change. For privacy questions or deletion requests, contact [insert support email].

---

**Production requirement:** If a cloud backend, user accounts, analytics, location, photos, support tools or third-party SDKs are added, update this policy and the store privacy disclosures so they accurately describe all collection, sharing, retention and deletion practices.
