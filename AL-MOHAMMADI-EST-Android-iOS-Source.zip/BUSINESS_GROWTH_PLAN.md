# Saudi pool-service business – practical growth plan

This plan is aimed at a small 1–5 person team. Use the app to make sales and delivery consistent; avoid expensive hiring or advertising until margins and capacity are understood.

## 1. Ideal customer groups

1. Villa owners: recurring pool cleaning and chemical treatment.
2. Residential compounds and property managers: multi-pool annual maintenance contracts.
3. Hotels, resorts, gyms and clubs: scheduled maintenance with service reports.
4. Pool builders and renovation contractors: post-construction handover maintenance, repair referrals and service partnerships.
5. Existing customers: equipment repair, filter/pump work and annual renewal offers.

Start in one city and nearby districts. Cluster visits by area to reduce technician travel time and fuel costs.

## 2. Package ladder

- **Essential:** scheduled cleaning, visual inspection and service log.
- **Complete:** Essential plus agreed water tests and chemical treatment, equipment checks and maintenance report.
- **Premium:** Complete plus more frequent visits and priority response terms.

Each quote must define pool size assumptions, visit frequency, included chemicals, exclusions, emergency charges, payment schedule, contract period and cancellation/renewal terms. Price from actual labour, travel, chemicals, equipment wear, overhead and target margin; do not copy competitors' prices without costing.

## 3. Sales process

1. Capture every enquiry in the CRM with lead source and follow-up date.
2. Qualify: pool type/size, address, service need, visit frequency and urgency.
3. Arrange a site inspection where required.
4. Send a numbered bilingual quotation PDF.
5. Follow up, record win/loss reason and convert accepted quotes to contracts.
6. Schedule recurring visits immediately after activation.
7. Send visit reports, collect payments and request a genuine review after good service.
8. Start renewal contact 30–45 days before contract expiry.

## 4. Low-cost customer acquisition

- Complete and maintain the company's Google Business Profile with real service areas, genuine job photos and customer reviews.
- Use WhatsApp Business catalogue, labels, greeting and quick replies. Send messages manually/with customer consent; do not claim this app automates messages yet.
- Approach property managers, villa maintenance firms, pool builders and compound managers with a concise capability sheet and sample service report.
- Ask satisfied clients for referrals. Track the referral source in the customer record.
- Publish useful bilingual content: water clarity, filter maintenance, safe pool care and seasonal pool preparation. Avoid unsupported safety or chemical claims.

## 5. Weekly owner dashboard review

Track these weekly:

- New qualified enquiries and lead source
- Quotes sent, won and lost
- Active AMC value and contract expiries
- Planned vs completed service visits
- Missed visits and customer complaints
- Amount invoiced, collected and overdue
- Direct costs by service line: cleaning, chemicals, repairs, construction
- Gross margin by service line
- Chemical stock below reorder level

Do not judge the company by revenue alone. Calculate direct labour, travel, chemicals, parts, subcontractor cost and rework before judging profitability.

## 6. First 90 days

- **Days 1–15:** confirm packages, standard scope/exclusions, bilingual quote and contract terms; enter current customers and open leads.
- **Days 16–30:** record every enquiry; contact past customers; set up Google Business Profile and WhatsApp Business; ask for genuine reviews.
- **Days 31–45:** schedule all maintenance visits in the app; cluster visits geographically; issue a service report after each visit.
- **Days 46–60:** reconcile payments weekly; track stock and chemical usage; identify the most profitable services.
- **Days 61–75:** approach property managers, compounds and pool contractors; offer inspection and tailored AMC quotes.
- **Days 76–90:** compare lead conversion, contract renewals, service completion and gross margin; expand only where technician capacity and unit economics support it.

## 7. Suggested launch targets (management goals, not promises)

- 100% of enquiries entered in the CRM.
- First follow-up within one business day.
- 100% of active AMCs have their next visit scheduled.
- 100% of completed visits have a service report.
- Review overdue balances every week.
- Ask every satisfied customer for a review/referral.
