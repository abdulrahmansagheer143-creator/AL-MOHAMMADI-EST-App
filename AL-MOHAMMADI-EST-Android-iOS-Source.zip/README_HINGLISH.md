# AL-MOHAMMADI EST – Android + iPhone app

Yeh ek **cross-platform React Native + Expo project** hai. Ek hi app codebase se Android aur iOS dono builds ban sakte hain.

## Is version mein kya kaam karta hai

- English / Arabic interface toggle (Arabic screen text right-to-left aligned hai).
- Business overview dashboard: collections, customers, active contracts, outstanding payments.
- Customer records: name, phone/WhatsApp, city, address, pool type, notes.
- Contracts / quotations: service type, amount in SAR, dates, visit frequency, scope, draft/active status.
- Contract PDF generate karke phone ke share menu se bhejna.
- Maintenance/service visits add karna aur complete mark karna.
- Payment records: paid/pending, SAR amount, method, dates.
- Chemical/equipment inventory and low-stock indicator.
- Company profile settings.
- App icon and launch screen branding.

## Important limitation – live company use se pehle

Yeh **Version 2.0 MVP / preview** hai, final production release nahi.

1. Records abhi sirf usi phone par local storage mein save hote hain. Alag employees ke phones ke beech sync nahi hota.
2. App login, employee roles, cloud backup, real-time sync aur central owner dashboard abhi connected nahi hain.
3. App ka payment tracker internal record hai; yeh ZATCA-compliant tax invoice ya e-invoicing integration nahi hai.
4. Service photos, digital signature, automatic WhatsApp sending, quotation approval link aur accounting exports abhi next development phase ke features hain.
5. Is preview mein sensitive/live customer ya bank data dalne se pehle secure cloud backend, access control, backups and privacy review complete karna hoga.

## Run the app

A computer with Node.js 22.13 or newer (Node 22.16+ recommended) is recommended.

```bash
npm install
npx expo install --fix
npx expo-doctor
npx expo start
```

- Android: Expo Go se QR code scan karke preview karein. Native PDF and sharing features ko final development/store build par bhi test karein.
- iPhone: Expo Go se QR code scan karke preview karein. App Store listing ke liye alag signed iOS build chahiye.

## Build installable Android / iOS apps

1. https://expo.dev par Expo account banayein.
2. Terminal mein:

```bash
npm install -g eas-cli
eas login
eas init
eas build:configure
```

`eas init` project ko aapke Expo account se link karega. Is command ke baad `app.json` mein Expo `projectId` add ho sakta hai.

3. Android test APK:

```bash
eas build --platform android --profile preview
```

4. Store builds:

```bash
eas build --platform all --profile production
```

Expo cloud build Android AAB aur iOS IPA produce kar sakta hai. Apple iOS signing ke liye Apple Developer credentials, aur store publishing ke liye relevant developer accounts ki zarurat hogi. EAS/Expo account aur build-service limits/charges alag ho sakte hain.

## Store publishing

- Google Play Console: developer account signup aur identity verification; Google currently US$25 one-time registration fee list karta hai. New personal developer accounts created after 13 Nov 2023 ko production access ke liye kam se kam 12 testers ka 14 consecutive days closed test chahiye.
- Apple App Store: Apple Developer Program membership currently US$99 per year (local currency/region pricing may vary). App Privacy information aur publicly accessible privacy policy URL required hai. Review approval guaranteed nahi hota.
- Store metadata, app screenshots, support contact, privacy policy, content rating and reviewer notes complete karne honge.

## Before real business rollout

First add a secure cloud backend (Supabase or Firebase) with authentication and organisation-level access rules. Suggested roles: Owner, Admin, Technician. The company owner must control user invites and data access. Add a tested backup/restore and data deletion process.

For Saudi use, have the company/accountant confirm commercial activity approvals, applicable VAT position and ZATCA e-invoicing obligations. Do not represent this MVP's payment receipt as a tax invoice.

## Branding

- App display name: `AL-MOHAMMADI EST`
- Arabic brand: `المحمدي` (display wording; confirm the official legal Arabic entity name before printing legal documents)
- Bundle/package ID: `com.almohammadi.est.poolservices`
- App icon: `assets/icon.png`
- Approved brand poster: `assets/al-mohammadi-est-brand-poster.jpg`
- Splash and launcher icon use a simplified crop of the approved Arabic droplet logo.
- Android adaptive icon: `assets/adaptive-icon.png`

Change the IDs before first store upload if the company has a preferred legal app identifier. Once published, bundle/package identifiers should not be changed.

## GitHub Actions se cloud build (optional)

The project includes `.github/workflows/expo-build.yml`. This workflow only works after the extracted project files (not just this ZIP) are committed to a GitHub repository and the project has been linked with `eas init`.

1. Expo account banayein aur `eas login` / `eas init` complete karein.
2. Expo dashboard se an Expo access token banayein.
3. GitHub repository → Settings → Secrets and variables → Actions → New repository secret.
4. Secret name `EXPO_TOKEN` rakhein, value mein Expo token paste karein.
5. GitHub → Actions → **Build AL-MOHAMMADI EST (Android + iOS)** → Run workflow.
6. Preview profile Android APK banata hai. Production profile store signing ke liye hai. iOS build ke liye Apple signing/account setup bhi required ho sakta hai.


## Version 2.1 additions

- Updated the app name and icon to AL-MOHAMMADI EST.
- Added a company brand banner on the dashboard.
- Added expense records and an operating result indicator (paid collections minus recorded expenses).
- Corrected the dashboard revenue metric to show payments recorded in the current calendar month.
- Added a shareable JSON data export. Treat the exported backup as confidential company data.

The project has not yet been run through a complete native build or physical-device QA in this environment. The backup export is not encrypted; share/store it securely.


### Version 2.1 update

- Company branding now reads **AL-MOHAMMADI EST** and uses the approved droplet logo.
- Dashboard includes expenses and a basic net operating result (paid receipts less recorded expenses).
- Current-month receipts are calculated using the payment date.
- A JSON backup export can be shared from More. The backup is not encrypted; protect it as confidential company data.
- A Hindi voice walkthrough video and its script are supplied separately with this source package.
