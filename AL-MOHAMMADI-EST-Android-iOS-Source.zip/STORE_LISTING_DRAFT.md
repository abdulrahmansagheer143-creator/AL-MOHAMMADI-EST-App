# Store listing draft – AL-MOHAMMADI EST

These are draft store materials. They must be updated to match the final production features before submission; do not claim cloud sync, automatic messaging, tax compliance or photo reporting until those features are actually implemented and tested.

## English

**App name:** AL-MOHAMMADI EST – Pool Services

**Short description:** Manage pool customers, service contracts, visits, payments and stock.

**Full description:**

AL-MOHAMMADI EST helps swimming pool service businesses organise their daily work in one place. Keep customer details, prepare service contracts and quotations, schedule maintenance visits, track payments and monitor chemical or equipment stock.

Features in this preview:
- Customer records and contact details
- Pool cleaning, chemical treatment, annual maintenance, repair and construction service categories
- Contract and quotation records with SAR values and service dates
- PDF contract sharing
- Maintenance visit scheduling and completion tracking
- Paid and pending payment records
- Inventory quantities and low-stock indicators
- English and Arabic interface

Designed for swimming pool service teams, maintenance providers and pool contractors in Saudi Arabia.

**Category suggestion:** Business

## Arabic

**اسم التطبيق:** مدير عقود وخدمات المسابح

**وصف مختصر:** إدارة العملاء وعقود صيانة المسابح والزيارات والمدفوعات والمخزون.

**وصف كامل:**

يساعد تطبيق مدير عقود وخدمات المسابح شركات تنظيف وصيانة المسابح على تنظيم العمل اليومي. يمكنك تسجيل بيانات العملاء، وإعداد سجلات العقود وعروض الأسعار، وجدولة زيارات الصيانة، ومتابعة المدفوعات، وإدارة مخزون المواد الكيميائية وقطع الغيار.

مزايا النسخة التجريبية:
- إدارة بيانات العملاء ووسائل التواصل
- تصنيفات تنظيف المسابح والمعالجة الكيميائية والصيانة السنوية والإصلاح والإنشاء
- تسجيل العقود وعروض الأسعار والقيم بالريال السعودي
- إنشاء ملفات PDF للعقود ومشاركتها
- جدولة زيارات الصيانة وتحديث حالتها
- تسجيل المدفوعات والمبالغ المعلقة
- متابعة المخزون والتنبيه عند انخفاض الكمية
- واجهة باللغتين العربية والإنجليزية

مصمم لمقدمي خدمات تنظيف وصيانة وإنشاء المسابح في المملكة العربية السعودية.

## Screenshot checklist

Capture genuine final-build screenshots (no mock screens) for:
1. Dashboard
2. Customer list and add customer form
3. Contract / quotation form
4. Generated bilingual PDF preview
5. Service visit list
6. Finance and inventory screens
7. Arabic RTL dashboard
