# AL-MOHAMMADI EST – next development roadmap

## Release 1 – Current MVP preview

- Bilingual English/Arabic interface
- Local customer records
- Contract and quotation records
- PDF generation and native share sheet
- Service visit scheduling/status
- Payment tracking (not a tax invoice)
- Inventory and low-stock indicators
- Company profile and app branding

## Release 1.1 – operational reliability

- Edit customer, contract, visit, payment and inventory records
- Customer profile with complete activity timeline
- Search, filters, due/overdue lists and reminders
- Export / restore a full data backup
- Service report PDF with technician notes and before/after photos
- E-signature or customer acknowledgement after legal review

## Release 2 – secure multi-employee company system (required before live multi-device use)

- Supabase/Firebase cloud database
- Company organisation and owner account
- Staff invitation, sign-in and role-based access
- Row-level security / organisation isolation
- Cloud sync across iOS and Android
- Encrypted transport, backups, audit log and data deletion workflow
- Server-side PDF numbering and document history

## Release 3 – revenue and field operations

- Leads pipeline and follow-up reminders
- Recurring maintenance plans and auto-generated visit schedules
- Technician assignment and route planning
- Customer approval and service report history
- AMC renewal reminders
- Referral-source and lead-conversion tracking
- Job costing for repairs and pool construction
- Supplier, chemical and spare-part purchase records

## Release 4 – Saudi finance integrations

- VAT settings and tax invoice review
- ZATCA e-invoicing integration through a suitable compliant provider / technical implementation
- Arabic/English invoice and quotation templates
- Accounting export (CSV/Excel) and reconciliation reports

No phase should be represented as complete until it is implemented, tested on physical devices and reviewed for security and legal compliance.


## Version 2.1 implemented in this source drop

- AL-MOHAMMADI EST branding, launcher icon and dashboard brand banner
- Expense record screen and net operating result indicator
- Monthly collections metric correction
- Shareable JSON data export

## Still required before company-wide production use

- Multi-device cloud database, authentication, Owner/Admin/Technician permissions, row-level data separation, backup/restore testing, and security review
- Record editing and full audit trail
- Technician service checklist, before/after photos and customer acknowledgements
- Repeating AMC visit creation and reminders
- ZATCA-compliant e-invoice integration via a tested compliant solution; this MVP does not issue tax invoices
- Legal/privacy review for Saudi PDPL and company-specific requirements
