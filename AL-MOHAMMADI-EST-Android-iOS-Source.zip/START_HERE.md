# Start here – AL-MOHAMMADI EST 2.1

## What this is

A single React Native / Expo codebase for Android and iPhone. It includes an operational MVP preview with Arabic/English UI, customer CRM, contracts/quotes, visits, payment records, inventory and contract PDF sharing.

## What you receive

- `App.js` – app source code
- `assets/` – AL-MOHAMMADI EST app icon artwork
- `app.json` – Android/iOS app identity and branding
- `package.json` – project dependencies
- `eas.json` – cloud build profiles
- `README_HINGLISH.md` – how to run/build
- `STORE_LISTING_DRAFT.md` – draft English and Arabic store copy
- `PRIVACY_POLICY_DRAFT.md` – privacy policy template to review and host
- `DEVELOPMENT_ROADMAP.md` – production development phases

## Important

This is not an already signed APK or IPA and it is not yet approved by either app store. It is a cross-platform source project. It currently saves data locally on one device only. Do not use it as the company's shared live system until cloud sync, login/roles, backups and security review are completed.

## Best next step

Have the project run on a computer using the steps in `README_HINGLISH.md`, test it with sample data on both an Android phone and an iPhone, then implement secure cloud accounts and company-wide sync before store submission.


The approved AL-MOHAMMADI EST logo is used in the app header and launcher/splash artwork.


## Branding and build status

This source uses AL-MOHAMMADI EST branding. It is an MVP preview source, not a verified APK/IPA. Validate it with `npx expo-doctor`, then build and test the Android APK and iOS preview. The Android GitHub workflow can create a debug APK once the source archive is uploaded to the linked repository.
