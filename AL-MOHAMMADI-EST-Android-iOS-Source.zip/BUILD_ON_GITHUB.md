# Build an AL-MOHAMMADI EST Android APK from GitHub

The repository workflow has already been added at:
`.github/workflows/build-al-mohammadi-apk.yml`

Repository: https://github.com/abdulrahmansagheer143-creator/Contract-Maker

## One-time upload

1. Download `AL-MOHAMMADI-EST-Android-iOS-Source.zip` from this delivery.
2. Open the repository in Chrome and choose **Add file → Upload files**.
3. Upload the ZIP into the repository root. Keep the filename exactly as shown above.
4. Enter a commit message and tap **Commit changes**.

The new workflow is triggered automatically by this upload. It installs the Expo SDK dependencies, generates the Android native project, and builds a debug APK.

## Download the APK

1. Open https://github.com/abdulrahmansagheer143-creator/Contract-Maker/actions.
2. Open **Build AL-MOHAMMADI EST Android APK**.
3. Open the latest successful run (green check mark).
4. Scroll to **Artifacts** and download `AL-MOHAMMADI-EST-Android-Preview-APK`.
5. Extract that ZIP and install `app-debug.apk` on the Android phone.

This is a debug/testing APK, not a Play Store release-signed APK. Only install builds from the company's own GitHub repository. Android may ask you to allow installation from the browser/file manager for this one file.

## iPhone build

The same Expo source targets iOS. An iOS simulator build can be created with EAS, but it cannot be installed on an ordinary iPhone. Installing on physical iPhones or publishing through TestFlight/App Store requires the appropriate Apple signing/distribution setup. Do not purchase a membership until the company has approved the app and is ready for iPhone distribution.
