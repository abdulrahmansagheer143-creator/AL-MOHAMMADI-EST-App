# AL-MOHAMMADI EST – Pool Services App (v2.1 preview)

A bilingual Arabic/English React Native + Expo application for a Saudi swimming-pool services business. The same codebase targets Android and iOS.

## Included in this preview

- AL-MOHAMMADI EST branding, approved Arabic droplet emblem, icon and dashboard banner
- English and Arabic interface toggle, with RTL-aligned Arabic text
- Owner overview: customers, active contracts, current-month recorded receipts, outstanding payments, expenses and a simple net operating result
- Customer register
- Service contracts and quotations, with PDF export/share
- Service-visit scheduling and completion status
- Payment record tracking (not a tax invoice)
- Expense records and basic inventory / reorder-level flag
- Shareable JSON data export

## Critical limitations

This is a local-first preview, not a production company system. Records are stored on the current device only. There is no authenticated multi-user cloud database, employee-role management, remote synchronisation, server-side backup, automated reminders, photo-based service reports, or edit/audit history. The JSON export is not encrypted; treat it as confidential business data. Do not enter live customer or bank data until secure cloud storage, access control, restore testing and a privacy review are completed. Payment records in this preview are not ZATCA tax invoices and do not implement FATOORA e-invoicing.

## Requirements and local checks

Expo SDK 58 targets React Native 0.88 and requires Node.js 22.13 or later on the Node 22 line. Use a supported current Node 22 release (22.16+ is suitable).

```bash
npm install
npx expo install --fix
npx expo-doctor
npx expo start
```

Use Expo Go for early UI tests, then a development or preview build for checking native PDF and file-sharing flows.

## Build Android APK with EAS

```bash
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```

For a local/CI debug APK without EAS account, the Android native project can be generated and built on an Android-capable CI runner after dependencies have been installed:

```bash
npx expo prebuild --platform android --no-install --non-interactive
cd android
./gradlew assembleDebug
```

The debug APK is for internal testing, not Play Store release.

## iOS builds

- `eas build --platform ios --profile ios-simulator` creates a simulator build that is not installable on an ordinary iPhone.
- Installing on physical iPhones or distributing through TestFlight/App Store requires Apple signing/distribution setup. Store publication requires an eligible Apple Developer Program membership.

## Android + iOS with EAS

An Expo account and an `EXPO_TOKEN` GitHub Actions secret are required for the included EAS cloud workflow. iOS device/store distribution also requires Apple signing credentials.

## Branding / package identifiers

- Display name: `AL-MOHAMMADI EST`
- Arabic brand display: `المحمدي` (confirm the exact legal Arabic entity name before using it in legal documents)
- Android application ID: `com.almohammadi.est.poolservices`
- iOS bundle ID: `com.almohammadi.est.poolservices`
- Main icon: `assets/icon.png`
- Full approved poster: `assets/al-mohammadi-est-brand-poster.jpg`

These IDs are proposed. Confirm the company's legal identity and ownership before a public release. Once an app is published, its application/bundle identifier should not be casually changed.

## Documentation

- `README_HINGLISH.md`: Hindi-English setup guide
- `START_HERE.md`: project introduction
- `DEVELOPMENT_ROADMAP.md`: production roadmap
- `BUSINESS_GROWTH_PLAN.md`: business growth plan
- `PRIVACY_POLICY_DRAFT.md`: draft to complete and publish after privacy review
- `STORE_LISTING_DRAFT.md`: bilingual store listing draft
- `HINDI_GUIDE_SCRIPT.md`: Hindi training narration script

## Legal / operations reminders for Saudi use

Confirm company licence/activity requirements, Saudi PDPL privacy handling, chemical safety obligations, tax registration status, and any applicable ZATCA e-invoicing requirements with qualified local support. The current preview is not an accounting or e-invoicing system.
