# AL-MOHAMMADI EST v2.1 – release status

## Updated in this delivery

- App name and brand changed to AL-MOHAMMADI EST.
- Approved droplet/calligraphy logo prepared for launcher icon and app header.
- Full approved brand poster added to the dashboard banner.
- Arabic/English interface retained.
- Expense records added to Finance.
- Dashboard now displays current-month recorded collections, total expense records and a simple net operating result.
- Shareable JSON export added.
- Hindi computer-generated voice walkthrough video and narration script included.
- GitHub Android debug APK workflow added to the previously connected repository.

## Not yet verified / not yet production ready

- An actual Android APK has not yet been built from this updated source.
- Physical-device QA on Android and iPhone has not been completed.
- App dependencies were not installed in this environment because the package-registry request timed out.
- Cloud sync, login, employee access roles, automated reminders and remote backups are not implemented.
- The JSON backup is not encrypted.
- Payment tracking is not a ZATCA tax invoice or e-invoicing integration.
- iOS physical-device distribution requires Apple signing/distribution setup.

Do not use this preview as the live system for confidential customer or payment records until security, backups, cloud roles and legal requirements have been implemented and tested.
