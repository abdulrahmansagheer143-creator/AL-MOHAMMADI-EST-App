import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator, Alert, Image, KeyboardAvoidingView, Modal, Platform, SafeAreaView,
  ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { File, Paths } from 'expo-file-system';

const STORAGE_KEY = '@contract-maker-v2';
const COLORS = {
  navy: '#092544', blue: '#0878C9', cyan: '#18B6D9', gold: '#E9B84C',
  bg: '#F3F7FB', card: '#FFFFFF', text: '#172B43', muted: '#718096',
  line: '#E3EAF2', green: '#15956B', red: '#D84C4C', amber: '#C58B20',
};

const EMPTY_DATA = {
  language: 'en',
  company: { name: 'AL-MOHAMMADI EST', nameAr: 'المحمدي', phone: '', email: '', city: '', cr: '', vat: '', address: '' },
  customers: [], contracts: [], visits: [], payments: [], expenses: [], inventory: [],
};

const I18N = {
  en: {
    appName: 'AL-MOHAMMADI EST', tagline: 'Swimming pool services', dashboard: 'Overview', customers: 'Customers', work: 'Operations', finance: 'Finance', more: 'More',
    welcome: 'Welcome back', today: "Here's your business at a glance.", revenue: 'Collected this month', customersTotal: 'Customers', activeContracts: 'Active contracts', duePayments: 'Outstanding', upcoming: 'Upcoming visits', quickActions: 'Quick actions', addCustomer: 'Add customer', newContract: 'New contract', scheduleVisit: 'Schedule visit', recordPayment: 'Record payment', recentActivity: 'Recent activity', recordsSaved: 'Your records are saved on this device. Cloud sync is a planned next step.', noActivity: 'No activity yet. Add your first customer to get started.',
    searchCustomers: 'Search customers by name or phone', add: 'Add', save: 'Save', cancel: 'Cancel', customerName: 'Customer name', phone: 'Phone / WhatsApp', city: 'City', address: 'Address / district', poolType: 'Pool type', notes: 'Notes',
    contracts: 'Contracts & quotes', visits: 'Service visits', stock: 'Inventory', contractTitle: 'Contract / quotation title', service: 'Service', annualValue: 'Contract value (SAR)', startDate: 'Start date (YYYY-MM-DD)', endDate: 'End date (YYYY-MM-DD)', frequency: 'Visit frequency', scope: 'Scope / included work', customer: 'Customer', selectCustomer: 'Enter customer name', status: 'Status', draft: 'Draft', active: 'Active', completed: 'Completed', scheduled: 'Scheduled', overdue: 'Overdue', create: 'Create', printShare: 'PDF / Share',
    visitDate: 'Visit date (YYYY-MM-DD)', technician: 'Assigned technician', visitNotes: 'Visit notes', markComplete: 'Mark complete',
    payments: 'Payments', amount: 'Amount (SAR)', method: 'Method', paymentDate: 'Payment date', dueDate: 'Due date', paid: 'Paid', pending: 'Pending', cash: 'Cash', bank: 'Bank transfer', card: 'Card', other: 'Other', record: 'Record', totalPaid: 'Total collected', totalDue: 'Balance due',
    product: 'Product / chemical', quantity: 'Quantity in stock', unit: 'Unit', reorder: 'Reorder level', lowStock: 'Low stock', addItem: 'Add stock item',
    companyProfile: 'Company profile', companyName: 'Company legal name', companyNameAr: 'Company name in Arabic', companyPhone: 'Company phone', companyEmail: 'Company email', companyAddress: 'Company address', cr: 'Commercial Registration (CR)', vat: 'VAT number (if registered)', language: 'App language', english: 'English', arabic: 'العربية', saveProfile: 'Save company profile', dataLocal: 'Local-first preview', localDesc: 'Records are currently saved on this device only. Cloud sync and employee accounts must be connected before using this for a multi-person live operation.', businessTools: 'Business tools', about: 'About this version', versionText: 'Version 2.1 preview • AL-MOHAMMADI EST pool services', emptyCustomers: 'No customers yet', emptyContracts: 'No contracts yet', emptyVisits: 'No visits scheduled', emptyPayments: 'No payments recorded', emptyStock: 'No stock items yet', choose: 'Choose', required: 'Please enter the required fields.', saved: 'Saved successfully.', delete: 'Delete', deleteConfirm: 'Delete this record?', all: 'All', serviceCleaning: 'Pool cleaning', serviceChemical: 'Chemical treatment', serviceAMC: 'Annual maintenance', serviceRepair: 'Pool repair', serviceConstruction: 'Pool construction', customerSince: 'Customer record', todayVisit: "Today's visits", manage: 'Manage', internalNote: 'Payment tracking in this preview is not a ZATCA tax invoice.', expense: 'Expenses', addExpense: 'Record expense', expenseTitle: 'Expense description', supplier: 'Supplier / payee', expenseCategory: 'Expense category', profit: 'Net operating result', totalExpenses: 'Recorded expenses', backup: 'Share data backup', guide: 'Hindi usage guide',
  },
  ar: {
    appName: 'مؤسسة المحمدي', tagline: 'خدمات المسابح والصيانة', dashboard: 'الرئيسية', customers: 'العملاء', work: 'العمليات', finance: 'المالية', more: 'المزيد',
    welcome: 'مرحباً بعودتك', today: 'ملخص أعمالك في مكان واحد.', revenue: 'المبالغ المحصلة هذا الشهر', customersTotal: 'العملاء', activeContracts: 'العقود النشطة', duePayments: 'المبالغ المستحقة', upcoming: 'الزيارات القادمة', quickActions: 'إجراءات سريعة', addCustomer: 'إضافة عميل', newContract: 'عقد جديد', scheduleVisit: 'جدولة زيارة', recordPayment: 'تسجيل دفعة', recentActivity: 'النشاط الأخير', recordsSaved: 'تم حفظ السجلات على هذا الجهاز. المزامنة السحابية ضمن التطوير القادم.', noActivity: 'لا يوجد نشاط حتى الآن. أضف أول عميل للبدء.',
    searchCustomers: 'ابحث بالاسم أو رقم الهاتف', add: 'إضافة', save: 'حفظ', cancel: 'إلغاء', customerName: 'اسم العميل', phone: 'الهاتف / واتساب', city: 'المدينة', address: 'العنوان / الحي', poolType: 'نوع المسبح', notes: 'ملاحظات',
    contracts: 'العقود وعروض الأسعار', visits: 'زيارات الخدمة', stock: 'المخزون', contractTitle: 'عنوان العقد / عرض السعر', service: 'الخدمة', annualValue: 'قيمة العقد (ريال)', startDate: 'تاريخ البداية (YYYY-MM-DD)', endDate: 'تاريخ النهاية (YYYY-MM-DD)', frequency: 'تكرار الزيارة', scope: 'نطاق العمل / الخدمات', customer: 'العميل', selectCustomer: 'أدخل اسم العميل', status: 'الحالة', draft: 'مسودة', active: 'نشط', completed: 'مكتمل', scheduled: 'مجدول', overdue: 'متأخر', create: 'إنشاء', printShare: 'PDF / مشاركة',
    visitDate: 'تاريخ الزيارة (YYYY-MM-DD)', technician: 'الفني المسؤول', visitNotes: 'ملاحظات الزيارة', markComplete: 'تحديد كمكتملة',
    payments: 'المدفوعات', amount: 'المبلغ (ريال)', method: 'طريقة الدفع', paymentDate: 'تاريخ الدفع', dueDate: 'تاريخ الاستحقاق', paid: 'مدفوع', pending: 'معلق', cash: 'نقداً', bank: 'تحويل بنكي', card: 'بطاقة', other: 'أخرى', record: 'تسجيل', totalPaid: 'إجمالي المحصل', totalDue: 'الرصيد المستحق',
    product: 'المنتج / المادة الكيميائية', quantity: 'الكمية المتوفرة', unit: 'الوحدة', reorder: 'حد إعادة الطلب', lowStock: 'مخزون منخفض', addItem: 'إضافة صنف',
    companyProfile: 'ملف الشركة', companyName: 'الاسم القانوني للشركة', companyNameAr: 'اسم الشركة بالعربية', companyPhone: 'هاتف الشركة', companyEmail: 'البريد الإلكتروني', companyAddress: 'عنوان الشركة', cr: 'السجل التجاري', vat: 'الرقم الضريبي (إن وجد)', language: 'لغة التطبيق', english: 'English', arabic: 'العربية', saveProfile: 'حفظ ملف الشركة', dataLocal: 'نسخة تجريبية محلية', localDesc: 'يتم حفظ البيانات حالياً على هذا الجهاز فقط. يجب ربط المزامنة السحابية وحسابات الموظفين قبل الاستخدام التشغيلي متعدد المستخدمين.', businessTools: 'أدوات الأعمال', about: 'حول هذه النسخة', versionText: 'نسخة 2.1 تجريبية • خدمات المسابح – المحمدي', emptyCustomers: 'لا يوجد عملاء بعد', emptyContracts: 'لا توجد عقود بعد', emptyVisits: 'لا توجد زيارات مجدولة', emptyPayments: 'لا توجد مدفوعات مسجلة', emptyStock: 'لا توجد أصناف في المخزون', choose: 'اختر', required: 'يرجى إدخال الحقول المطلوبة.', saved: 'تم الحفظ بنجاح.', delete: 'حذف', deleteConfirm: 'هل تريد حذف هذا السجل؟', all: 'الكل', serviceCleaning: 'تنظيف المسبح', serviceChemical: 'معالجة كيميائية', serviceAMC: 'صيانة سنوية', serviceRepair: 'إصلاح المسبح', serviceConstruction: 'إنشاء المسبح', customerSince: 'سجل العميل', todayVisit: 'زيارات اليوم', manage: 'إدارة', internalNote: 'تتبع المدفوعات في هذه النسخة ليس فاتورة ضريبية من هيئة الزكاة والضريبة والجمارك.', expense: 'المصروفات', addExpense: 'تسجيل مصروف', expenseTitle: 'وصف المصروف', supplier: 'المورد / المستفيد', expenseCategory: 'فئة المصروف', profit: 'صافي نتيجة التشغيل', totalExpenses: 'إجمالي المصروفات المسجلة', backup: 'مشاركة نسخة احتياطية', guide: 'دليل الاستخدام باللغة الهندية',
  },
};

const SERVICES = [
  { id: 'cleaning', key: 'serviceCleaning' }, { id: 'chemical', key: 'serviceChemical' },
  { id: 'amc', key: 'serviceAMC' }, { id: 'repair', key: 'serviceRepair' },
  { id: 'construction', key: 'serviceConstruction' },
];
const id = () => `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const money = (v) => `SAR ${Number(v || 0).toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
const sum = (list, key) => (list || []).reduce((a, x) => a + Number(x[key] || 0), 0);
const safe = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function Button({ title, onPress, secondary = false, small = false, danger = false, style }) {
  return <TouchableOpacity onPress={onPress} activeOpacity={0.85} style={[styles.button, secondary && styles.buttonSecondary, danger && styles.buttonDanger, small && styles.buttonSmall, style]}>
    <Text style={[styles.buttonText, secondary && styles.buttonSecondaryText, danger && styles.buttonDangerText, small && styles.buttonSmallText]}>{title}</Text>
  </TouchableOpacity>;
}
function Field({ label, value, onChangeText, placeholder, keyboardType, multiline, rtl, editable = true }) {
  return <View style={styles.fieldWrap}>
    <Text style={[styles.fieldLabel, rtl && styles.rtlText]}>{label}</Text>
    <TextInput value={value == null ? '' : String(value)} onChangeText={onChangeText} placeholder={placeholder || label} placeholderTextColor="#9AA9BA"
      keyboardType={keyboardType || 'default'} multiline={multiline} editable={editable}
      textAlign={rtl ? 'right' : 'left'} style={[styles.input, multiline && styles.inputMultiline, rtl && { writingDirection: 'rtl' }]} />
  </View>;
}
function Pill({ text, type = 'blue' }) {
  const map = { blue: [ '#E6F3FC', '#176FA8' ], green: ['#E6F7F0', '#147A56'], amber: ['#FFF4DC', '#986A12'], red: ['#FDECEC', '#B73535'], gray: ['#EEF2F6', '#5F7082'] };
  return <View style={[styles.pill, { backgroundColor: map[type][0] }]}><Text style={[styles.pillText, { color: map[type][1] }]}>{text}</Text></View>;
}
function SectionTitle({ title, action, onAction, rtl }) {
  return <View style={[styles.sectionRow, rtl && { flexDirection: 'row-reverse' }]}>
    <Text style={[styles.sectionTitle, rtl && styles.rtlText]}>{title}</Text>
    {action ? <TouchableOpacity onPress={onAction}><Text style={styles.link}>{action}</Text></TouchableOpacity> : null}
  </View>;
}
function Empty({ text }) { return <View style={styles.empty}><Text style={styles.emptyIcon}>⌁</Text><Text style={styles.emptyText}>{text}</Text></View>; }

export default function App() {
  const [data, setData] = useState(EMPTY_DATA);
  const [loaded, setLoaded] = useState(false);
  const [tab, setTab] = useState('dashboard');
  const [workTab, setWorkTab] = useState('contracts');
  const [financeTab, setFinanceTab] = useState('payments');
  const [query, setQuery] = useState('');
  const [modal, setModal] = useState(null);
  const [draft, setDraft] = useState({});
  const [busy, setBusy] = useState(false);
  const lang = data.language || 'en';
  const rtl = lang === 'ar';
  const t = (k) => I18N[lang][k] || I18N.en[k] || k;

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) { const parsed = JSON.parse(raw); const company = { ...EMPTY_DATA.company, ...(parsed.company || {}) }; if (!company.name) company.name = 'AL-MOHAMMADI EST'; if (!company.nameAr) company.nameAr = 'المحمدي'; setData({ ...EMPTY_DATA, ...parsed, company, customers: parsed.customers || [], contracts: parsed.contracts || [], visits: parsed.visits || [], payments: parsed.payments || [], expenses: parsed.expenses || [], inventory: parsed.inventory || [] }); }
      } catch (e) { Alert.alert('Storage error', 'Saved records could not be loaded.'); }
      setLoaded(true);
    })();
  }, []);

  useEffect(() => {
    if (!loaded) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data)).catch(() => Alert.alert('Save error', 'Could not save this change on the device.'));
  }, [data, loaded]);

  const collected = useMemo(() => sum(data.payments.filter(x => x.status === 'paid'), 'amount'), [data.payments]);
  const monthKey = today().slice(0, 7);
  const collectedThisMonth = useMemo(() => sum(data.payments.filter(x => x.status === 'paid' && String(x.date || '').startsWith(monthKey)), 'amount'), [data.payments, monthKey]);
  const pending = useMemo(() => sum(data.payments.filter(x => x.status !== 'paid'), 'amount'), [data.payments]);
  const expenseTotal = useMemo(() => sum(data.expenses, 'amount'), [data.expenses]);
  const netResult = collected - expenseTotal;
  const activeContracts = data.contracts.filter(x => x.status === 'active').length;
  const upcomingVisits = data.visits.filter(x => x.status !== 'completed').sort((a,b) => (a.date || '').localeCompare(b.date || '')).slice(0, 4);
  const customerName = (name) => name || (rtl ? 'عميل' : 'Customer');

  const startAdd = (kind) => {
    const common = { customer: '', notes: '' };
    const defaults = {
      customer: { name: '', phone: '', city: data.company.city || 'Jeddah', address: '', poolType: 'Private villa', notes: '' },
      contract: { title: '', customer: data.customers[0]?.name || '', service: 'amc', amount: '', startDate: today(), endDate: '', frequency: 'Weekly', scope: '', status: 'draft' },
      visit: { customer: data.customers[0]?.name || '', service: 'cleaning', date: today(), technician: '', status: 'scheduled', notes: '' },
      payment: { customer: data.customers[0]?.name || '', amount: '', method: 'bank', date: today(), dueDate: today(), status: 'paid', reference: '' },
      inventory: { product: '', quantity: '', unit: 'pcs', reorder: '', supplier: '', notes: '' },
      expense: { title: '', supplier: '', category: 'Chemicals', amount: '', date: today(), notes: '' },
    };
    setDraft(defaults[kind] || common);
    setModal(kind);
  };
  const updateDraft = (k, v) => setDraft(prev => ({ ...prev, [k]: v }));
  const closeModal = () => { setModal(null); setDraft({}); };

  const saveModal = () => {
    const nameOrTitle = modal === 'customer' ? draft.name : modal === 'inventory' ? draft.product : modal === 'expense' ? draft.title : modal === 'contract' ? draft.title : modal === 'visit' ? draft.customer : draft.customer;
    if (!String(nameOrTitle || '').trim()) { Alert.alert(t('required')); return; }
    if (['contract', 'payment', 'expense'].includes(modal) && !String(draft.amount || '').trim()) { Alert.alert(t('required')); return; }
    const record = { ...draft, id: id(), createdAt: new Date().toISOString() };
    if (modal === 'contract') {
      if (!record.endDate && record.startDate) { const d = new Date(`${record.startDate}T00:00:00`); d.setFullYear(d.getFullYear() + 1); d.setDate(d.getDate() - 1); record.endDate = d.toISOString().slice(0,10); }
      record.amount = Number(record.amount || 0);
    }
    if (modal === 'payment' || modal === 'expense') record.amount = Number(record.amount || 0);
    if (modal === 'inventory') { record.quantity = Number(record.quantity || 0); record.reorder = Number(record.reorder || 0); }
    const key = ({ customer: 'customers', contract: 'contracts', visit: 'visits', payment: 'payments', expense: 'expenses', inventory: 'inventory' })[modal];
    setData(prev => ({ ...prev, [key]: [record, ...prev[key]] }));
    closeModal();
    Alert.alert(t('saved'));
  };

  const deleteRecord = (key, recordId) => Alert.alert(t('delete'), t('deleteConfirm'), [
    { text: t('cancel'), style: 'cancel' },
    { text: t('delete'), style: 'destructive', onPress: () => setData(prev => ({ ...prev, [key]: prev[key].filter(x => x.id !== recordId) })) },
  ]);

  const toggleVisit = (record) => setData(prev => ({ ...prev, visits: prev.visits.map(x => x.id === record.id ? { ...x, status: x.status === 'completed' ? 'scheduled' : 'completed' } : x) }));
  const statusType = (status) => status === 'active' || status === 'paid' || status === 'completed' ? 'green' : status === 'overdue' ? 'red' : status === 'pending' ? 'amber' : 'blue';
  const serviceLabel = (idValue) => { const found = SERVICES.find(x => x.id === idValue); return found ? t(found.key) : idValue || '—'; };

  const printContract = async (c) => {
    const company = data.company;
    const arabic = `<div dir="rtl" style="text-align:right;font-family:Arial,sans-serif"><h2>${safe(company.nameAr || company.name || 'اسم الشركة')}</h2><p>${safe(company.address)} | ${safe(company.phone)}</p><hr/><h1>عقد صيانة / عرض سعر</h1><p><b>رقم المرجع:</b> ${safe(c.id.slice(-7))}</p><p><b>العميل:</b> ${safe(c.customer)}</p><p><b>الخدمة:</b> ${safe(serviceLabel(c.service))}</p><p><b>القيمة:</b> ${safe(c.amount)} ريال سعودي</p><p><b>من:</b> ${safe(c.startDate)} <b>إلى:</b> ${safe(c.endDate)}</p><p><b>تكرار الزيارة:</b> ${safe(c.frequency)}</p><p><b>نطاق العمل:</b> ${safe(c.scope)}</p><br/><p>توقيع العميل: ____________________</p><p>توقيع الشركة: ____________________</p></div>`;
    const english = `<div style="font-family:Arial,sans-serif"><h2>${safe(company.name || 'Company name')}</h2><p>${safe(company.address)} | ${safe(company.phone)}</p><hr/><h1>Service Contract / Quotation</h1><p><b>Reference:</b> ${safe(c.id.slice(-7))}</p><p><b>Customer:</b> ${safe(c.customer)}</p><p><b>Service:</b> ${safe(serviceLabel(c.service))}</p><p><b>Contract value:</b> SAR ${safe(c.amount)}</p><p><b>Period:</b> ${safe(c.startDate)} to ${safe(c.endDate)}</p><p><b>Visit frequency:</b> ${safe(c.frequency)}</p><p><b>Scope of work:</b> ${safe(c.scope)}</p><br/><p>Customer signature: ____________________</p><p>Company signature: ____________________</p></div>`;
    try {
      setBusy(true);
      const result = await Print.printToFileAsync({ html: `<!doctype html><html><head><meta charset="utf-8"><style>body{font-size:14px;line-height:1.8;padding:28px;color:#17324e}hr{border:0;border-top:2px solid #0b82c5}</style></head><body>${arabic}<br/><hr/>${english}</body></html>` });
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(result.uri, { mimeType: 'application/pdf', dialogTitle: 'Share contract PDF' });
      else Alert.alert('PDF created', result.uri);
    } catch (e) { Alert.alert('PDF error', 'Could not create the contract PDF on this device.'); }
    finally { setBusy(false); }
  };

  const switchLanguage = (value) => setData(prev => ({ ...prev, language: value }));
  const shareBackup = async () => { try { const file = new File(Paths.cache, `AL-MOHAMMADI-EST-backup-${today()}.json`); if (file.exists) file.delete(); file.create(); await file.write(JSON.stringify({ app: 'AL-MOHAMMADI EST', schemaVersion: 1, exportedAt: new Date().toISOString(), data }, null, 2)); await Sharing.shareAsync(file.uri, { mimeType: 'application/json', dialogTitle: 'Share company data backup' }); } catch (e) { Alert.alert('Backup error', 'Could not create or share the backup on this device.'); } };
  const saveCompanyField = (key, value) => setData(prev => ({ ...prev, company: { ...prev.company, [key]: value } }));

  if (!loaded) return <SafeAreaView style={styles.loading}><ActivityIndicator size="large" color={COLORS.blue}/><Text style={styles.loadingText}>AL-MOHAMMADI EST</Text></SafeAreaView>;

  const Header = () => <View style={[styles.header, rtl && { flexDirection: 'row-reverse' }]}>
    <Image source={require('./assets/icon.png')} style={styles.brandImage} resizeMode="cover"/>
    <View style={{ flex: 1 }}><Text style={[styles.headerTitle, rtl && styles.rtlText]}>AL-MOHAMMADI EST</Text><Text style={[styles.headerSub, rtl && styles.rtlText]}>{t('tagline')}</Text></View>
    <View style={styles.langMini}><Text style={styles.langMiniText}>{lang === 'en' ? 'EN' : 'عر'}</Text></View>
  </View>;

  const Metric = ({ label, value, icon, tone = 'blue' }) => <View style={styles.metric}>
    <View style={[styles.metricIcon, tone === 'green' && { backgroundColor: '#E6F7F0' }, tone === 'amber' && { backgroundColor: '#FFF4DC' }]}><Text style={styles.metricIconText}>{icon}</Text></View>
    <Text style={styles.metricValue}>{value}</Text><Text style={[styles.metricLabel, rtl && styles.rtlText]}>{label}</Text>
  </View>;

  const Dashboard = () => <ScrollView contentContainerStyle={styles.page} showsVerticalScrollIndicator={false}>
    <View style={styles.brandHero}><Image source={require('./assets/al-mohammadi-est-brand-poster.jpg')} style={styles.heroPoster} resizeMode="cover"/><View style={styles.heroCaption}><Text style={styles.heroBrand}>AL-MOHAMMADI EST</Text><Text style={styles.heroSub}>SWIMMING POOL SERVICES</Text></View></View>
    <Text style={[styles.hello, rtl && styles.rtlText]}>{t('welcome')}{data.company.name ? `, ${data.company.name}` : ''}</Text>
    <Text style={[styles.pageSub, rtl && styles.rtlText]}>{t('today')}</Text>
    <View style={styles.metricsGrid}>
      <Metric label={t('revenue')} value={money(collectedThisMonth)} icon="↗" tone="green"/>
      <Metric label={t('customersTotal')} value={data.customers.length} icon="◎"/>
      <Metric label={t('activeContracts')} value={activeContracts} icon="▤" tone="green"/>
      <Metric label={t('duePayments')} value={money(pending)} icon="◷" tone="amber"/>
      <Metric label={t('totalExpenses')} value={money(expenseTotal)} icon="−" tone="amber"/>
      <Metric label={t('profit')} value={money(netResult)} icon="=" tone={netResult >= 0 ? 'green' : 'amber'}/>
    </View>
    <SectionTitle title={t('quickActions')} rtl={rtl}/>
    <View style={styles.quickGrid}>
      <QuickAction title={t('addCustomer')} icon="＋" onPress={() => startAdd('customer')}/>
      <QuickAction title={t('newContract')} icon="▤" onPress={() => { setTab('work'); setWorkTab('contracts'); startAdd('contract'); }}/>
      <QuickAction title={t('scheduleVisit')} icon="◷" onPress={() => { setTab('work'); setWorkTab('visits'); startAdd('visit'); }}/>
      <QuickAction title={t('recordPayment')} icon="＄" onPress={() => { setTab('finance'); startAdd('payment'); }}/>
    </View>
    <SectionTitle title={t('upcoming')} action={t('manage')} onAction={() => { setTab('work'); setWorkTab('visits'); }} rtl={rtl}/>
    {upcomingVisits.length ? upcomingVisits.map(v => <View key={v.id} style={styles.listCard}>
      <View style={styles.listMain}><Text style={[styles.listTitle, rtl && styles.rtlText]}>{customerName(v.customer)}</Text><Text style={[styles.listSub, rtl && styles.rtlText]}>{serviceLabel(v.service)} • {v.date || '—'}</Text></View>
      <Pill text={v.status === 'completed' ? t('completed') : t('scheduled')} type={statusType(v.status)}/>
    </View>) : <Empty text={t('emptyVisits')}/>}
    <SectionTitle title={t('recentActivity')} rtl={rtl}/>
    {data.customers.length || data.contracts.length || data.payments.length ? <View style={styles.noticeCard}><Text style={styles.noticeIcon}>✓</Text><Text style={[styles.noticeText, rtl && styles.rtlText]}>{t('recordsSaved')}</Text></View> : <Empty text={t('noActivity')}/>}
  </ScrollView>;

  const QuickAction = ({ title, icon, onPress }) => <TouchableOpacity onPress={onPress} style={styles.quickAction} activeOpacity={0.86}><Text style={styles.quickIcon}>{icon}</Text><Text style={[styles.quickTitle, rtl && styles.rtlText]}>{title}</Text></TouchableOpacity>;

  const Customers = () => {
    const filtered = data.customers.filter(c => `${c.name} ${c.phone} ${c.city}`.toLowerCase().includes(query.toLowerCase()));
    return <ScrollView contentContainerStyle={styles.page} keyboardShouldPersistTaps="handled">
      <SectionTitle title={t('customers')} action={`＋ ${t('add')}`} onAction={() => startAdd('customer')} rtl={rtl}/>
      <TextInput value={query} onChangeText={setQuery} placeholder={t('searchCustomers')} placeholderTextColor="#9AA9BA" style={[styles.search, rtl && { textAlign: 'right', writingDirection: 'rtl' }]}/>
      {filtered.length ? filtered.map(c => <View key={c.id} style={styles.recordCard}>
        <View style={[styles.recordTop, rtl && { flexDirection: 'row-reverse' }]}>
          <View style={styles.avatar}><Text style={styles.avatarText}>{(c.name || 'C').slice(0,1).toUpperCase()}</Text></View>
          <View style={{ flex: 1 }}><Text style={[styles.listTitle, rtl && styles.rtlText]}>{c.name}</Text><Text style={[styles.listSub, rtl && styles.rtlText]}>{c.phone || '—'} • {c.city || '—'}</Text></View>
          <Pill text={c.poolType || 'Pool'} type="blue"/>
        </View>
        <Text style={[styles.recordAddress, rtl && styles.rtlText]}>{c.address || c.notes || '—'}</Text>
        <View style={[styles.recordActions, rtl && { flexDirection: 'row-reverse' }]}><Text style={styles.metaText}>{t('customerSince')}: {(c.createdAt || '').slice(0,10)}</Text><Button title={t('delete')} small danger onPress={() => deleteRecord('customers', c.id)}/></View>
      </View>) : <Empty text={t('emptyCustomers')}/>}
    </ScrollView>;
  };

  const TabSwitch = ({ items, value, onChange }) => <View style={[styles.segment, rtl && { flexDirection: 'row-reverse' }]}>{items.map(item => <TouchableOpacity key={item.id} onPress={() => onChange(item.id)} style={[styles.segmentItem, value === item.id && styles.segmentActive]}><Text style={[styles.segmentText, value === item.id && styles.segmentTextActive]}>{item.label}</Text></TouchableOpacity>)}</View>;

  const Work = () => <ScrollView contentContainerStyle={styles.page}>
    <SectionTitle title={t('work')} rtl={rtl}/>
    <TabSwitch value={workTab} onChange={setWorkTab} items={[{ id: 'contracts', label: t('contracts') }, { id: 'visits', label: t('visits') }, { id: 'stock', label: t('stock') }]}/>
    {workTab === 'contracts' ? <>
      <SectionTitle title={t('contracts')} action={`＋ ${t('add')}`} onAction={() => startAdd('contract')} rtl={rtl}/>
      {data.contracts.length ? data.contracts.map(c => <View key={c.id} style={styles.recordCard}>
        <View style={[styles.recordTop, rtl && { flexDirection: 'row-reverse' }]}><View style={{ flex: 1 }}><Text style={[styles.listTitle, rtl && styles.rtlText]}>{c.title}</Text><Text style={[styles.listSub, rtl && styles.rtlText]}>{c.customer} • {serviceLabel(c.service)}</Text></View><Pill text={t(c.status)} type={statusType(c.status)}/></View>
        <Text style={styles.amountLarge}>{money(c.amount)}</Text><Text style={[styles.listSub, rtl && styles.rtlText]}>{c.startDate} → {c.endDate} • {c.frequency}</Text>
        {c.scope ? <Text style={[styles.recordAddress, rtl && styles.rtlText]}>{c.scope}</Text> : null}
        <View style={[styles.recordActions, rtl && { flexDirection: 'row-reverse' }]}><Button title={t('printShare')} small onPress={() => printContract(c)}/><Button title={t('delete')} small danger onPress={() => deleteRecord('contracts', c.id)}/></View>
      </View>) : <Empty text={t('emptyContracts')}/>}</> : null}
    {workTab === 'visits' ? <>
      <SectionTitle title={t('visits')} action={`＋ ${t('add')}`} onAction={() => startAdd('visit')} rtl={rtl}/>
      {data.visits.length ? data.visits.map(v => <View key={v.id} style={styles.recordCard}>
        <View style={[styles.recordTop, rtl && { flexDirection: 'row-reverse' }]}><View style={{ flex: 1 }}><Text style={[styles.listTitle, rtl && styles.rtlText]}>{v.customer}</Text><Text style={[styles.listSub, rtl && styles.rtlText]}>{serviceLabel(v.service)} • {v.date}</Text><Text style={[styles.metaText, rtl && styles.rtlText]}>{v.technician || '—'}</Text></View><Pill text={t(v.status)} type={statusType(v.status)}/></View>
        {v.notes ? <Text style={[styles.recordAddress, rtl && styles.rtlText]}>{v.notes}</Text> : null}
        <View style={[styles.recordActions, rtl && { flexDirection: 'row-reverse' }]}><Button title={v.status === 'completed' ? t('scheduled') : t('markComplete')} small onPress={() => toggleVisit(v)}/><Button title={t('delete')} small danger onPress={() => deleteRecord('visits', v.id)}/></View>
      </View>) : <Empty text={t('emptyVisits')}/>}</> : null}
    {workTab === 'stock' ? <>
      <SectionTitle title={t('stock')} action={`＋ ${t('add')}`} onAction={() => startAdd('inventory')} rtl={rtl}/>
      {data.inventory.length ? data.inventory.map(p => <View key={p.id} style={styles.recordCard}>
        <View style={[styles.recordTop, rtl && { flexDirection: 'row-reverse' }]}><View style={{ flex: 1 }}><Text style={[styles.listTitle, rtl && styles.rtlText]}>{p.product}</Text><Text style={[styles.listSub, rtl && styles.rtlText]}>{p.supplier || '—'}</Text></View><Pill text={Number(p.quantity) <= Number(p.reorder) ? t('lowStock') : `${p.quantity} ${p.unit}`} type={Number(p.quantity) <= Number(p.reorder) ? 'amber' : 'green'}/></View>
        <Text style={[styles.metaText, rtl && styles.rtlText]}>{t('reorder')}: {p.reorder} {p.unit}</Text><View style={styles.recordActions}><Button title={t('delete')} small danger onPress={() => deleteRecord('inventory', p.id)}/></View>
      </View>) : <Empty text={t('emptyStock')}/>}</> : null}
  </ScrollView>;

  const Finance = () => <ScrollView contentContainerStyle={styles.page}>
    <SectionTitle title={t('finance')} action={`＋ ${financeTab === 'payments' ? t('record') : t('addExpense')}`} onAction={() => startAdd(financeTab === 'payments' ? 'payment' : 'expense')} rtl={rtl}/>
    <View style={styles.metricsGrid}><Metric label={t('totalPaid')} value={money(collected)} icon="✓" tone="green"/><Metric label={t('totalDue')} value={money(pending)} icon="◷" tone="amber"/><Metric label={t('totalExpenses')} value={money(expenseTotal)} icon="−" tone="amber"/><Metric label={t('profit')} value={money(netResult)} icon="=" tone={netResult >= 0 ? 'green' : 'amber'}/></View>
    <View style={styles.noteBox}><Text style={[styles.noteText, rtl && styles.rtlText]}>ⓘ {t('internalNote')}</Text></View>
    <TabSwitch value={financeTab} onChange={setFinanceTab} items={[{ id: 'payments', label: t('payments') }, { id: 'expenses', label: t('expense') }]}/>
    {financeTab === 'payments' ? <>
      <SectionTitle title={t('payments')} rtl={rtl}/>
      {data.payments.length ? data.payments.map(p => <View key={p.id} style={styles.recordCard}>
        <View style={[styles.recordTop, rtl && { flexDirection: 'row-reverse' }]}><View style={{ flex: 1 }}><Text style={[styles.listTitle, rtl && styles.rtlText]}>{p.customer}</Text><Text style={[styles.listSub, rtl && styles.rtlText]}>{p.date} • {t(p.method)}</Text></View><Pill text={t(p.status)} type={statusType(p.status)}/></View>
        <Text style={styles.amountLarge}>{money(p.amount)}</Text><Text style={[styles.metaText, rtl && styles.rtlText]}>{p.reference || ''} {p.dueDate ? `• ${t('dueDate')}: ${p.dueDate}` : ''}</Text>
        <View style={styles.recordActions}><Button title={p.status === 'paid' ? t('pending') : t('paid')} small onPress={() => setData(prev => ({ ...prev, payments: prev.payments.map(x => x.id === p.id ? { ...x, status: x.status === 'paid' ? 'pending' : 'paid' } : x) }))}/><Button title={t('delete')} small danger onPress={() => deleteRecord('payments', p.id)}/></View>
      </View>) : <Empty text={t('emptyPayments')}/>}</> : <>
      <SectionTitle title={t('expense')} rtl={rtl}/>
      {data.expenses.length ? data.expenses.map(e => <View key={e.id} style={styles.recordCard}>
        <View style={[styles.recordTop, rtl && { flexDirection: 'row-reverse' }]}><View style={{ flex: 1 }}><Text style={[styles.listTitle, rtl && styles.rtlText]}>{e.title}</Text><Text style={[styles.listSub, rtl && styles.rtlText]}>{e.date} • {e.category || 'General'}</Text></View><Pill text={e.supplier || t('supplier')} type="gray"/></View>
        <Text style={styles.amountLarge}>{money(e.amount)}</Text><Text style={[styles.metaText, rtl && styles.rtlText]}>{e.notes || ''}</Text>
        <View style={styles.recordActions}><Button title={t('delete')} small danger onPress={() => deleteRecord('expenses', e.id)}/></View>
      </View>) : <Empty text={rtl ? 'لا توجد مصروفات مسجلة' : 'No expenses recorded yet'}/>}</>}
  </ScrollView>;

  const More = () => <ScrollView contentContainerStyle={styles.page}>
    <SectionTitle title={t('more')} rtl={rtl}/>
    <View style={styles.card}>
      <Text style={[styles.cardTitle, rtl && styles.rtlText]}>{t('companyProfile')}</Text>
      <Field label={t('companyName')} value={data.company.name} onChangeText={v => saveCompanyField('name', v)} rtl={rtl}/>
      <Field label={t('companyNameAr')} value={data.company.nameAr} onChangeText={v => saveCompanyField('nameAr', v)} rtl={true}/>
      <Field label={t('companyPhone')} value={data.company.phone} onChangeText={v => saveCompanyField('phone', v)} keyboardType="phone-pad" rtl={rtl}/>
      <Field label={t('companyEmail')} value={data.company.email} onChangeText={v => saveCompanyField('email', v)} keyboardType="email-address" rtl={rtl}/>
      <Field label={t('city')} value={data.company.city} onChangeText={v => saveCompanyField('city', v)} rtl={rtl}/>
      <Field label={t('companyAddress')} value={data.company.address} onChangeText={v => saveCompanyField('address', v)} rtl={rtl}/>
      <Field label={t('cr')} value={data.company.cr} onChangeText={v => saveCompanyField('cr', v)} rtl={rtl}/>
      <Field label={t('vat')} value={data.company.vat} onChangeText={v => saveCompanyField('vat', v)} rtl={rtl}/>
      <Text style={[styles.fieldLabel, rtl && styles.rtlText]}>{t('language')}</Text>
      <View style={[styles.langRow, rtl && { flexDirection: 'row-reverse' }]}><Button title={t('english')} secondary={lang !== 'en'} onPress={() => switchLanguage('en')} style={{ flex: 1 }}/><Button title={t('arabic')} secondary={lang !== 'ar'} onPress={() => switchLanguage('ar')} style={{ flex: 1 }}/></View>
    </View>
    <View style={styles.card}><Text style={[styles.cardTitle, rtl && styles.rtlText]}>{rtl ? 'النسخ الاحتياطي' : 'Data backup'}</Text><Text style={[styles.listSub, rtl && styles.rtlText]}>{rtl ? 'أنشئ نسخة احتياطية وشاركها بأمان. لا ترسل الملف إلى أشخاص غير مصرح لهم.' : 'Create a backup and keep it in a secure company location. Do not share it with unauthorised people.'}</Text><Button title={t('backup')} onPress={shareBackup} style={{ marginTop: 10 }}/></View>
    <View style={styles.noteBox}><Text style={[styles.noteTitle, rtl && styles.rtlText]}>{t('dataLocal')}</Text><Text style={[styles.noteText, rtl && styles.rtlText]}>{t('localDesc')}</Text></View>
    <View style={styles.card}><Text style={[styles.cardTitle, rtl && styles.rtlText]}>{t('about')}</Text><Text style={[styles.listSub, rtl && styles.rtlText]}>{t('versionText')}</Text></View>
  </ScrollView>;

  const screen = tab === 'dashboard' ? Dashboard() : tab === 'customers' ? Customers() : tab === 'work' ? Work() : tab === 'finance' ? Finance() : More();
  const navItems = [ ['dashboard', '⌂', t('dashboard')], ['customers', '♙', t('customers')], ['work', '▦', t('work')], ['finance', '＄', t('finance')], ['more', '•••', t('more')] ];

  const formTitle = ({ customer: t('addCustomer'), contract: t('newContract'), visit: t('scheduleVisit'), payment: t('recordPayment'), expense: t('addExpense'), inventory: t('addItem') })[modal];
  const renderFormFields = () => {
    if (modal === 'customer') return <>
      <Field label={`${t('customerName')} *`} value={draft.name} onChangeText={v => updateDraft('name', v)} rtl={rtl}/>
      <Field label={t('phone')} value={draft.phone} onChangeText={v => updateDraft('phone', v)} keyboardType="phone-pad" rtl={rtl}/>
      <Field label={t('city')} value={draft.city} onChangeText={v => updateDraft('city', v)} rtl={rtl}/>
      <Field label={t('address')} value={draft.address} onChangeText={v => updateDraft('address', v)} rtl={rtl}/>
      <Field label={t('poolType')} value={draft.poolType} onChangeText={v => updateDraft('poolType', v)} rtl={rtl}/>
      <Field label={t('notes')} value={draft.notes} onChangeText={v => updateDraft('notes', v)} multiline rtl={rtl}/>
    </>;
    if (modal === 'contract') return <>
      <Field label={`${t('contractTitle')} *`} value={draft.title} onChangeText={v => updateDraft('title', v)} rtl={rtl}/>
      <Field label={`${t('customer')} *`} value={draft.customer} onChangeText={v => updateDraft('customer', v)} placeholder={`${t('selectCustomer')}${data.customers.length ? ` (${data.customers.length} saved)` : ''}`} rtl={rtl}/>
      <Text style={[styles.fieldLabel, rtl && styles.rtlText]}>{t('service')}</Text><View style={styles.chips}>{SERVICES.map(s => <TouchableOpacity key={s.id} onPress={() => updateDraft('service', s.id)} style={[styles.chip, draft.service === s.id && styles.chipActive]}><Text style={[styles.chipText, draft.service === s.id && styles.chipTextActive]}>{t(s.key)}</Text></TouchableOpacity>)}</View>
      <Field label={`${t('annualValue')} *`} value={draft.amount} onChangeText={v => updateDraft('amount', v)} keyboardType="decimal-pad" rtl={rtl}/>
      <Field label={t('startDate')} value={draft.startDate} onChangeText={v => updateDraft('startDate', v)} rtl={rtl}/><Field label={t('endDate')} value={draft.endDate} onChangeText={v => updateDraft('endDate', v)} rtl={rtl}/>
      <Field label={t('frequency')} value={draft.frequency} onChangeText={v => updateDraft('frequency', v)} rtl={rtl}/><Field label={t('scope')} value={draft.scope} onChangeText={v => updateDraft('scope', v)} multiline rtl={rtl}/>
      <Text style={[styles.fieldLabel, rtl && styles.rtlText]}>{t('status')}</Text><View style={styles.chips}>{['draft','active'].map(s => <TouchableOpacity key={s} onPress={() => updateDraft('status', s)} style={[styles.chip, draft.status === s && styles.chipActive]}><Text style={[styles.chipText, draft.status === s && styles.chipTextActive]}>{t(s)}</Text></TouchableOpacity>)}</View>
    </>;
    if (modal === 'visit') return <>
      <Field label={`${t('customer')} *`} value={draft.customer} onChangeText={v => updateDraft('customer', v)} rtl={rtl}/>
      <Text style={[styles.fieldLabel, rtl && styles.rtlText]}>{t('service')}</Text><View style={styles.chips}>{SERVICES.map(s => <TouchableOpacity key={s.id} onPress={() => updateDraft('service', s.id)} style={[styles.chip, draft.service === s.id && styles.chipActive]}><Text style={[styles.chipText, draft.service === s.id && styles.chipTextActive]}>{t(s.key)}</Text></TouchableOpacity>)}</View>
      <Field label={t('visitDate')} value={draft.date} onChangeText={v => updateDraft('date', v)} rtl={rtl}/><Field label={t('technician')} value={draft.technician} onChangeText={v => updateDraft('technician', v)} rtl={rtl}/><Field label={t('visitNotes')} value={draft.notes} onChangeText={v => updateDraft('notes', v)} multiline rtl={rtl}/>
    </>;
    if (modal === 'expense') return <>
      <Field label={`${t('expenseTitle')} *`} value={draft.title} onChangeText={v => updateDraft('title', v)} rtl={rtl}/>
      <Field label={t('supplier')} value={draft.supplier} onChangeText={v => updateDraft('supplier', v)} rtl={rtl}/>
      <Field label={t('expenseCategory')} value={draft.category} onChangeText={v => updateDraft('category', v)} rtl={rtl}/>
      <Field label={`${t('amount')} *`} value={draft.amount} onChangeText={v => updateDraft('amount', v)} keyboardType="decimal-pad" rtl={rtl}/>
      <Field label={t('paymentDate')} value={draft.date} onChangeText={v => updateDraft('date', v)} rtl={rtl}/>
      <Field label={t('notes')} value={draft.notes} onChangeText={v => updateDraft('notes', v)} multiline rtl={rtl}/>
    </>;
    if (modal === 'payment') return <>
      <Field label={`${t('customer')} *`} value={draft.customer} onChangeText={v => updateDraft('customer', v)} rtl={rtl}/><Field label={`${t('amount')} *`} value={draft.amount} onChangeText={v => updateDraft('amount', v)} keyboardType="decimal-pad" rtl={rtl}/>
      <Text style={[styles.fieldLabel, rtl && styles.rtlText]}>{t('method')}</Text><View style={styles.chips}>{['cash','bank','card','other'].map(s => <TouchableOpacity key={s} onPress={() => updateDraft('method', s)} style={[styles.chip, draft.method === s && styles.chipActive]}><Text style={[styles.chipText, draft.method === s && styles.chipTextActive]}>{t(s)}</Text></TouchableOpacity>)}</View>
      <Field label={t('paymentDate')} value={draft.date} onChangeText={v => updateDraft('date', v)} rtl={rtl}/><Field label={t('dueDate')} value={draft.dueDate} onChangeText={v => updateDraft('dueDate', v)} rtl={rtl}/><Field label={t('notes')} value={draft.reference} onChangeText={v => updateDraft('reference', v)} rtl={rtl}/>
      <Text style={[styles.fieldLabel, rtl && styles.rtlText]}>{t('status')}</Text><View style={styles.chips}>{['paid','pending'].map(s => <TouchableOpacity key={s} onPress={() => updateDraft('status', s)} style={[styles.chip, draft.status === s && styles.chipActive]}><Text style={[styles.chipText, draft.status === s && styles.chipTextActive]}>{t(s)}</Text></TouchableOpacity>)}</View>
    </>;
    return <><Field label={`${t('product')} *`} value={draft.product} onChangeText={v => updateDraft('product', v)} rtl={rtl}/><Field label={t('quantity')} value={draft.quantity} onChangeText={v => updateDraft('quantity', v)} keyboardType="decimal-pad" rtl={rtl}/><Field label={t('unit')} value={draft.unit} onChangeText={v => updateDraft('unit', v)} rtl={rtl}/><Field label={t('reorder')} value={draft.reorder} onChangeText={v => updateDraft('reorder', v)} keyboardType="decimal-pad" rtl={rtl}/><Field label={t('notes')} value={draft.supplier} onChangeText={v => updateDraft('supplier', v)} rtl={rtl}/></>;
  };

  return <SafeAreaView style={styles.safe}>
    <StatusBar barStyle="light-content" backgroundColor={COLORS.navy}/>
    {Header()}
    <View style={{ flex: 1 }}>{screen}</View>
    <View style={[styles.bottomNav, rtl && { flexDirection: 'row-reverse' }]}>
      {navItems.map(([key, icon, label]) => <TouchableOpacity key={key} onPress={() => { setTab(key); setQuery(''); }} style={[styles.navItem, tab === key && styles.navActive]}>
        <Text style={[styles.navIcon, tab === key && styles.navIconActive]}>{icon}</Text><Text style={[styles.navLabel, tab === key && styles.navLabelActive]}>{label}</Text>
      </TouchableOpacity>)}
    </View>
    <Modal visible={!!modal} animationType="slide" presentationStyle="pageSheet" onRequestClose={closeModal}>
      <SafeAreaView style={styles.modalSafe}>
        <View style={[styles.modalHeader, rtl && { flexDirection: 'row-reverse' }]}><Text style={[styles.modalTitle, rtl && styles.rtlText]}>{formTitle}</Text><TouchableOpacity onPress={closeModal}><Text style={styles.closeX}>✕</Text></TouchableOpacity></View>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <ScrollView contentContainerStyle={styles.modalBody} keyboardShouldPersistTaps="handled">{renderFormFields()}</ScrollView>
          <View style={styles.modalFooter}><Button title={t('cancel')} secondary onPress={closeModal} style={{ flex: 1 }}/><Button title={t('save')} onPress={saveModal} style={{ flex: 1 }}/></View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </Modal>
    {busy ? <View style={styles.busyOverlay}><ActivityIndicator color="#fff" size="large"/><Text style={{ color: '#fff', marginTop: 10 }}>Preparing PDF…</Text></View> : null}
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg }, loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.bg }, loadingText: { marginTop: 12, color: COLORS.navy, fontWeight: '700' },
  header: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.navy, paddingHorizontal: 18, paddingVertical: 13 },
  brandHero: { height: 145, overflow: 'hidden', borderRadius: 18, marginBottom: 17, backgroundColor: COLORS.navy, borderWidth: 1, borderColor: COLORS.gold }, heroPoster: { width: '100%', height: '100%', opacity: 0.78 }, heroCaption: { position: 'absolute', left: 14, bottom: 12, backgroundColor: '#071C35CC', paddingHorizontal: 10, paddingVertical: 7, borderRadius: 9 }, heroBrand: { color: '#fff', fontWeight: '900', fontSize: 16, letterSpacing: 1 }, heroSub: { color: '#F0C86F', fontWeight: '700', fontSize: 9, letterSpacing: 2, marginTop: 2 }, brandImage: { width: 46, height: 46, borderRadius: 13, marginRight: 11, borderWidth: 1, borderColor: COLORS.gold }, headerTitle: { fontWeight: '800', color: '#fff', fontSize: 17 }, headerSub: { color: '#C5D6E7', fontSize: 11, marginTop: 2 }, langMini: { borderWidth: 1, borderColor: '#49647F', borderRadius: 9, paddingHorizontal: 9, paddingVertical: 5 }, langMiniText: { color: '#fff', fontWeight: '700', fontSize: 11 },
  page: { padding: 16, paddingBottom: 30 }, hello: { fontSize: 23, color: COLORS.navy, fontWeight: '800', marginTop: 3 }, pageSub: { color: COLORS.muted, fontSize: 13, marginTop: 5, marginBottom: 18 }, rtlText: { textAlign: 'right', writingDirection: 'rtl' }, sectionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 18, marginBottom: 10 }, sectionTitle: { color: COLORS.navy, fontWeight: '800', fontSize: 16 }, link: { color: COLORS.blue, fontWeight: '700', fontSize: 13 },
  metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 }, metric: { width: '48%', flexGrow: 1, minHeight: 112, backgroundColor: '#fff', borderRadius: 16, borderWidth: 1, borderColor: COLORS.line, padding: 13 }, metricIcon: { width: 28, height: 28, borderRadius: 9, backgroundColor: '#E7F3FC', alignItems: 'center', justifyContent: 'center' }, metricIconText: { color: COLORS.blue, fontSize: 17, fontWeight: '900' }, metricValue: { color: COLORS.navy, fontSize: 18, fontWeight: '800', marginTop: 10 }, metricLabel: { color: COLORS.muted, fontSize: 11, marginTop: 3 },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 }, quickAction: { width: '48%', flexGrow: 1, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.line, padding: 13, borderRadius: 14, minHeight: 81 }, quickIcon: { color: COLORS.blue, fontSize: 22, fontWeight: '800' }, quickTitle: { color: COLORS.text, fontSize: 12, fontWeight: '700', marginTop: 8 }, empty: { backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.line, borderRadius: 14, padding: 22, alignItems: 'center' }, emptyIcon: { color: '#8FB7D5', fontSize: 29 }, emptyText: { color: COLORS.muted, textAlign: 'center', marginTop: 5, fontSize: 13 },
  listCard: { backgroundColor: '#fff', borderRadius: 13, padding: 13, borderWidth: 1, borderColor: COLORS.line, marginBottom: 9, flexDirection: 'row', alignItems: 'center', gap: 8 }, listMain: { flex: 1 }, listTitle: { color: COLORS.text, fontSize: 14, fontWeight: '800' }, listSub: { color: COLORS.muted, fontSize: 12, marginTop: 4 }, pill: { borderRadius: 20, paddingHorizontal: 9, paddingVertical: 5, alignSelf: 'flex-start' }, pillText: { fontSize: 10, fontWeight: '800' }, noticeCard: { backgroundColor: '#EAF6FC', borderRadius: 14, borderWidth: 1, borderColor: '#CDE8F7', padding: 14, flexDirection: 'row', alignItems: 'center', gap: 10 }, noticeIcon: { fontSize: 18, color: COLORS.green, fontWeight: '900' }, noticeText: { color: COLORS.text, flex: 1, fontSize: 12 },
  bottomNav: { flexDirection: 'row', backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: COLORS.line, paddingHorizontal: 4, paddingTop: 6, paddingBottom: Platform.OS === 'ios' ? 4 : 8 }, navItem: { flex: 1, alignItems: 'center', paddingVertical: 5, borderRadius: 11 }, navActive: { backgroundColor: '#EAF5FC' }, navIcon: { color: '#74869A', fontSize: 20, height: 23 }, navIconActive: { color: COLORS.blue }, navLabel: { fontSize: 9, color: '#74869A', marginTop: 2, fontWeight: '600' }, navLabelActive: { color: COLORS.blue, fontWeight: '800' },
  search: { backgroundColor: '#fff', borderColor: COLORS.line, borderWidth: 1, borderRadius: 12, paddingHorizontal: 13, paddingVertical: 11, fontSize: 13, color: COLORS.text, marginBottom: 12 }, recordCard: { backgroundColor: '#fff', borderColor: COLORS.line, borderWidth: 1, borderRadius: 15, padding: 13, marginBottom: 10 }, recordTop: { flexDirection: 'row', alignItems: 'center', gap: 10 }, avatar: { width: 39, height: 39, borderRadius: 12, backgroundColor: '#E7F3FC', alignItems: 'center', justifyContent: 'center' }, avatarText: { color: COLORS.blue, fontWeight: '900', fontSize: 16 }, recordAddress: { color: COLORS.muted, fontSize: 12, marginTop: 10 }, recordActions: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 11, justifyContent: 'flex-end' }, metaText: { color: '#8795A5', fontSize: 10, flex: 1 }, amountLarge: { color: COLORS.navy, fontWeight: '900', fontSize: 19, marginTop: 10 },
  button: { backgroundColor: COLORS.blue, paddingHorizontal: 15, paddingVertical: 11, borderRadius: 11, alignItems: 'center', justifyContent: 'center' }, buttonText: { color: '#fff', fontSize: 13, fontWeight: '800' }, buttonSecondary: { backgroundColor: '#EAF1F7' }, buttonSecondaryText: { color: COLORS.navy }, buttonDanger: { backgroundColor: '#FCECEC' }, buttonDangerText: { color: COLORS.red }, buttonSmall: { paddingHorizontal: 11, paddingVertical: 7, borderRadius: 9 }, buttonSmallText: { fontSize: 11 },
  segment: { flexDirection: 'row', backgroundColor: '#E8EFF5', borderRadius: 12, padding: 4, marginBottom: 7 }, segmentItem: { flex: 1, paddingVertical: 10, borderRadius: 9, alignItems: 'center' }, segmentActive: { backgroundColor: '#fff', elevation: 1 }, segmentText: { color: COLORS.muted, fontSize: 11, fontWeight: '700' }, segmentTextActive: { color: COLORS.navy },
  card: { backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.line, borderRadius: 15, padding: 14, marginBottom: 12 }, cardTitle: { fontSize: 15, color: COLORS.navy, fontWeight: '800', marginBottom: 8 }, fieldWrap: { marginTop: 9 }, fieldLabel: { color: '#52677E', fontWeight: '700', fontSize: 11, marginBottom: 5 }, input: { backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#DCE5EE', borderRadius: 10, paddingHorizontal: 11, paddingVertical: 10, color: COLORS.text, fontSize: 13, minHeight: 42 }, inputMultiline: { minHeight: 74, textAlignVertical: 'top' }, langRow: { flexDirection: 'row', gap: 9, marginTop: 8 }, noteBox: { backgroundColor: '#FFF7E7', borderWidth: 1, borderColor: '#F5E3B9', padding: 13, borderRadius: 13, marginVertical: 10 }, noteTitle: { color: '#825B15', fontWeight: '800', fontSize: 13, marginBottom: 4 }, noteText: { color: '#806A3B', fontSize: 11, lineHeight: 17 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: 3, marginBottom: 5 }, chip: { borderWidth: 1, borderColor: '#DAE4ED', backgroundColor: '#F8FAFC', paddingHorizontal: 10, paddingVertical: 8, borderRadius: 18 }, chipActive: { borderColor: COLORS.blue, backgroundColor: '#E6F3FC' }, chipText: { color: '#60748A', fontSize: 11, fontWeight: '700' }, chipTextActive: { color: COLORS.blue },
  modalSafe: { flex: 1, backgroundColor: COLORS.bg }, modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: COLORS.line, backgroundColor: '#fff' }, modalTitle: { color: COLORS.navy, fontSize: 17, fontWeight: '900' }, closeX: { color: COLORS.muted, fontSize: 20, padding: 4 }, modalBody: { padding: 17, paddingBottom: 30 }, modalFooter: { flexDirection: 'row', padding: 14, gap: 10, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: COLORS.line }, busyOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: '#081C31CC', alignItems: 'center', justifyContent: 'center', zIndex: 100 },
});
